//>>built
define("dijit/form/nls/pl/Textarea",({iframeEditTitle:"edycja obszaru",iframeFocusTitle:"edycja ramki obszaru"}));
