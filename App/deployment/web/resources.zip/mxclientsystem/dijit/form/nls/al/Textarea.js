//>>built
define("dijit/form/nls/al/Textarea",{iframeEditTitle:"zona e editimit",iframeFocusTitle:"frame i zonës së editimit"});
