//>>built
define("dijit/form/nls/fr/Textarea",({iframeEditTitle:"zone d'édition",iframeFocusTitle:"cadre de la zone d'édition"}));
